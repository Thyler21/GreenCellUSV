#!/bin/bash

set -u

PDIR="$3"
PBIN="$LBPBIN/$PDIR"
PCGI="$LBPHTMLAUTH/$PDIR"

chmod 0755 "$PBIN/greencell-ups-test.sh"
chmod 0755 "$PBIN/greencell-ups-nut-service.sh" "$PBIN/greencell-ups-publisher.pl"
chmod 0755 "$PCGI/index.cgi"
chmod 0755 "$PCGI/state.cgi"
echo "<OK> GreenCellUSV files are ready."

exit 0
