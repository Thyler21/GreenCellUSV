# GreenCellUSV for LoxBerry 4

GreenCellUSV 0.3.1 monitors a GreenCell PowerProof 600 VA / 360 W connected as
MEC MEC0003 (`0001:0000`). It uses the Debian NUT driver `nutdrv_qx` with the
Q1 protocol in a plugin-local configuration.

The web page shows mains operation, battery operation, low battery warning,
input/output voltage, frequency, load, battery voltage, estimated charge and
estimated runtime. It retains all values through the LoxBerry MQTT Gateway.

Default MQTT base topic: `loxberry/greencellusv`

Key topics: `mode`, `status`, `load_percent`, `battery_voltage`,
`battery_charge_percent`, `battery_runtime_minutes`, `battery_low`,
`availability`, and the complete JSON object in `state`.

The percentage and runtime values are estimates based on a 12 V 7.2 Ah AGM
battery and can be adjusted in the web interface. The verified model is the
PowerProof 600. A custom MEC/Q1 profile is available for experiments.

The plugin does not modify the APC UPS plugin or `/etc/nut/ups.conf`.

## Installation

Upload the ZIP in LoxBerry Plugin Management. The installer installs NUT,
creates and starts the isolated driver and publisher services, and uses the
LoxBerry MQTT Gateway already configured on the system.
