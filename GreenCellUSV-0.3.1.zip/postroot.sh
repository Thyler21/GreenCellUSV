#!/bin/bash
set -u
PDIR="$3"; SOURCE_DIR="$6"; PBIN="$LBPBIN/$PDIR"; PCONFIG="$LBPCONFIG/$PDIR"; PDATA="$LBPDATA/$PDIR"
systemctl stop greencellups-publisher.service greencellups-nut.service 2>/dev/null || true
for unit in greencellups-nut.service greencellups-publisher.service; do sed "s|REPLACELBPBINDIR|$PBIN|g" "$SOURCE_DIR/systemd/$unit" > "/etc/systemd/system/$unit"; chmod 0644 "/etc/systemd/system/$unit"; done
chmod 0755 "$PBIN/greencell-ups-nut-service.sh" "$PBIN/greencell-ups-publisher.pl"
chown -R loxberry:loxberry "$PCONFIG" "$PDATA"
systemctl daemon-reload
systemctl enable greencellups-nut.service greencellups-publisher.service
systemctl restart greencellups-nut.service
systemctl restart greencellups-publisher.service
echo "<OK> GreenCellUSV monitoring and MQTT publisher started."
exit 0
