#!/bin/bash
systemctl disable --now greencellups-publisher.service greencellups-nut.service 2>/dev/null || true
rm -f /etc/systemd/system/greencellups-publisher.service /etc/systemd/system/greencellups-nut.service
systemctl daemon-reload
exit 0
