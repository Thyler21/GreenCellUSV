#!/usr/bin/perl
use strict; use warnings;
use CGI qw(escapeHTML); use HTML::Template; use JSON::PP;
use LoxBerry::System; use LoxBerry::Web;
sub read_json { my($p,$f)=@_; return $f if !-r$p; open my$h,'<',$p or return$f; local$/; my$r=<$h>; close$h; return eval{decode_json($r)}||$f }
sub save_json { my($p,$v)=@_; my$t="$p.tmp.$$"; open my$h,'>',$t or die$!; print$h JSON::PP->new->canonical->pretty->encode($v); close$h; rename$t,$p or die$! }
my$q=CGI->new; my$path="$lbpconfigdir/pluginconfig.json"; my$c=read_json($path,{}); my$msg='';
if(($ENV{REQUEST_METHOD}||'')eq'POST'){
 my$m=$q->param('model')||'powerproof600'; $m='powerproof600' if$m!~/^(?:powerproof600|custom_q1)$/;
 my%n=%$c; my%lim=(battery_voltage=>[6,96],battery_ah=>[1,500],rated_va=>[100,20000],rated_watts=>[50,20000],poll_interval=>[5,300]);
 for my$k(keys%lim){my$v=$q->param($k);next if!defined$v||$v!~/^\d+(?:\.\d+)?$/;my($a,$b)=@{$lim{$k}};$v=$a if$v<$a;$v=$b if$v>$b;$n{$k}=0+$v}
 my$t=$q->param('mqtt_base_topic')||'loxberry/greencellusv';$t=~s/[^A-Za-z0-9_\-\/.]//g;$t=~s{^/+|/+$}{}g;
 $n{model}=$m;$n{model_name}=$m eq'powerproof600'?'PowerProof 600 VA':'Benutzerdefinierte Q1-USV';$n{battery_type}='AGM';$n{battery_count}=1;$n{mqtt_enabled}=$q->param('mqtt_enabled')?JSON::PP::true:JSON::PP::false;$n{mqtt_base_topic}=$t||'loxberry/greencellusv';save_json($path,\%n);$c=\%n;$msg='Einstellungen gespeichert.';
}
my$v=LoxBerry::System::pluginversion();my$txt=LoxBerry::System::read_file("$lbptemplatedir/index.html");my$tpl=HTML::Template->new_scalar_ref(\$txt,global_vars=>1,die_on_bad_params=>0);
my$usb=qx{/usr/bin/lsusb -d 0001:0000 2>/dev/null};chomp$usb;my($drv)=grep{-x$_}qw(/lib/nut/nutdrv_qx /usr/lib/nut/nutdrv_qx /usr/sbin/nutdrv_qx);
$tpl->param(VERSION=>escapeHTML($v),ICON_URL=>"/system/images/icons/$lbpplugindir/icon_128.png",USB_TEXT=>$usb?'Verbunden':'Nicht gefunden',USB_CLASS=>$usb?'ok':'bad',USB_DETAIL=>escapeHTML($usb||'USB 0001:0000 ist nicht erreichbar'),DRIVER_TEXT=>$drv?'Bereit':'Nicht gefunden',DRIVER_CLASS=>$drv?'ok':'bad',MESSAGE=>escapeHTML($msg),SHOW_MESSAGE=>$msg?1:0,MODEL_600=>($c->{model}||'')eq'powerproof600',MODEL_CUSTOM=>($c->{model}||'')eq'custom_q1',BATTERY_VOLTAGE=>escapeHTML($c->{battery_voltage}//12),BATTERY_AH=>escapeHTML($c->{battery_ah}//7.2),RATED_VA=>escapeHTML($c->{rated_va}//600),RATED_WATTS=>escapeHTML($c->{rated_watts}//360),MQTT_ENABLED=>$c->{mqtt_enabled}?1:0,MQTT_TOPIC=>escapeHTML($c->{mqtt_base_topic}||'loxberry/greencellusv'),POLL_INTERVAL=>escapeHTML($c->{poll_interval}//10));
LoxBerry::Web::lbheader("GreenCellUSV V$v",'','help.html','nojqm');print$tpl->output;LoxBerry::Web::lbfooter();
