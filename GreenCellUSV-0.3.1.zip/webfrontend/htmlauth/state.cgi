#!/usr/bin/perl
use strict; use warnings; use LoxBerry::System;
print "Content-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\n\r\n";
if(open my$h,'<',"$lbpdatadir/state.json"){local$/;print scalar<$h>;close$h}else{print'{"available":false,"mode":"offline","mode_text":"Nicht verbunden"}'}
